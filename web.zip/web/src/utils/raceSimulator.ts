import { RaceState, RaceParticipant, Card } from '../types/game';

export function calculateSpeed(cards: Card[]): number {
  if (cards.length === 0) return 0.3;
  
  const avgStability = cards.reduce((sum, c) => sum + c.stats.stability, 0) / cards.length;
  const avgBurst = cards.reduce((sum, c) => sum + c.stats.burst, 0) / cards.length;
  const avgDelay = cards.reduce((sum, c) => sum + c.stats.delay, 0) / cards.length;
  const avgPredictability = cards.reduce((sum, c) => sum + c.stats.predictability, 0) / cards.length;
  
  // Base speed calculation
  const baseSpeed = (avgStability * 0.4 + avgBurst * 0.3 + avgPredictability * 0.3) / 100;
  
  // Delay penalty
  const delayPenalty = Math.max(0, 1 - (avgDelay / 200));
  
  return Math.max(0.1, Math.min(1.0, baseSpeed * delayPenalty));
}

export function generateCommentary(
  participant: RaceParticipant,
  opponent: RaceParticipant,
  elapsedTime: number
): string[] {
  const comments: string[] = [];
  const posDiff = participant.position - opponent.position;
  
  if (elapsedTime < 2000) {
    comments.push('比赛开始！双方网络都在加速中...');
  } else if (elapsedTime < 5000) {
    if (posDiff > 5) {
      comments.push(`${participant.name} 表现优异，保持领先！`);
    } else if (posDiff < -5) {
      comments.push(`${participant.name} 落后了，需要加把劲！`);
    } else {
      comments.push('双方势均力敌，竞争激烈！');
    }
  } else if (elapsedTime < 8000) {
    if (posDiff > 10) {
      comments.push(`${participant.name} 的优势明显，连接非常稳定！`);
    } else if (posDiff < -10) {
      comments.push(`${participant.name} 遇到了困难，网络质量不稳定...`);
    } else {
      comments.push('比赛进入白热化阶段！');
    }
  } else {
    if (posDiff > 5) {
      comments.push(`${participant.name} 即将获胜！`);
    } else if (posDiff < -5) {
      comments.push(`${participant.name} 还能赶上吗？`);
    } else {
      comments.push('最后冲刺，胜负难料！');
    }
  }
  
  return comments;
}

export function simulateRaceStep(
  raceState: RaceState,
  deltaTime: number
): RaceState {
  const newState = { ...raceState };
  newState.elapsedTime += deltaTime;
  
  // Update participant speeds based on cards
  newState.participants = newState.participants.map((p) => {
    const baseSpeed = calculateSpeed(p.cards);
    
    // Add randomness based on predictability
    const avgPredictability = p.cards.reduce((sum, c) => sum + c.stats.predictability, 0) / p.cards.length;
    const randomness = (100 - avgPredictability) / 100;
    const speedVariation = (Math.random() - 0.5) * randomness * 0.3;
    
    const currentSpeed = Math.max(0.1, Math.min(1.0, baseSpeed + speedVariation));
    
    // Update position
    const speedMultiplier = currentSpeed * (deltaTime / 100); // Normalize to percentage per second
    const newPosition = Math.min(100, p.position + speedMultiplier);
    
    return {
      ...p,
      position: newPosition,
      speed: currentSpeed,
    };
  });
  
  // Generate commentary
  const user = newState.participants.find((p) => p.id === 'user')!;
  const opponent = newState.participants.find((p) => p.id === 'opponent')!;
  const newComments = generateCommentary(user, opponent, newState.elapsedTime);
  
  if (newComments.length > 0 && newState.commentary.length === 0) {
    newState.commentary = newComments;
  } else if (newComments.length > 0 && Math.random() > 0.7) {
    newState.commentary = [...newState.commentary.slice(-2), ...newComments];
  }
  
  return newState;
}
