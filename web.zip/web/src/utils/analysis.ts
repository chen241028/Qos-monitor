import { Card } from '../types/game';

export function generateAnalysis(
  userCards: Card[],
  userPosition: number,
  opponentPosition: number
): {
  strengths: string[];
  limitations: string[];
  improvements: string[];
} {
  const strengths: string[] = [];
  const limitations: string[] = [];
  const improvements: string[] = [];
  
  const avgStability = userCards.reduce((sum, c) => sum + c.stats.stability, 0) / userCards.length;
  const avgBurst = userCards.reduce((sum, c) => sum + c.stats.burst, 0) / userCards.length;
  const avgDelay = userCards.reduce((sum, c) => sum + c.stats.delay, 0) / userCards.length;
  const avgPredictability = userCards.reduce((sum, c) => sum + c.stats.predictability, 0) / userCards.length;
  
  // Strengths
  if (avgStability > 80) {
    strengths.push('你的网络稳定性出色，连接保持稳定');
  }
  if (avgBurst > 75) {
    strengths.push('你的网络爆发力强，能快速响应需求');
  }
  if (avgDelay < 20) {
    strengths.push('延迟极低，响应速度令人满意');
  }
  if (avgPredictability > 80) {
    strengths.push('网络表现可预测，行为一致性好');
  }
  
  // Limitations
  if (avgStability < 60) {
    limitations.push('网络稳定性不足，连接波动较大');
  }
  if (avgBurst < 50) {
    limitations.push('爆发力有限，难以应对突发流量');
  }
  if (avgDelay > 50) {
    limitations.push('延迟较高，响应速度需要改进');
  }
  if (avgPredictability < 60) {
    limitations.push('网络行为难以预测，稳定性待提升');
  }
  
  // Improvements
  if (userPosition < opponentPosition) {
    improvements.push('考虑使用更高稀有度的卡片来提升网络质量');
    if (avgStability < 70) {
      improvements.push('优先选择稳定性更高的网络配置');
    }
    if (avgDelay > 30) {
      improvements.push('尝试降低网络延迟，选择更优的路由');
    }
  } else {
    improvements.push('继续保持当前配置的优势');
    if (avgBurst < 70) {
      improvements.push('可以尝试提升网络的爆发性能');
    }
  }
  
  return { strengths, limitations, improvements };
}
