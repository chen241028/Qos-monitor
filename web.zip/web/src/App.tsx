import { useGameStore } from './store/gameStore';
import { StartScreen } from './components/StartScreen';
import { CardDrawPhase } from './components/CardDrawPhase';
import { RacePhase } from './components/RacePhase';
import { ResultPhase } from './components/ResultPhase';
import { GrafanaPanel } from './components/GrafanaPanel';

function App() {
  const phase = useGameStore((state) => state.phase);

  // Show Grafana panel on right side for all phases except start
  const showGrafana = phase !== 'start';

  console.log('App rendered, phase:', phase);

  return (
    <div className="min-h-screen flex" style={{ backgroundColor: '#0A0A0F', minHeight: '100vh' }}>
      <div className={`flex-1 ${showGrafana ? 'w-2/3' : 'w-full'}`} style={{ minHeight: '100vh' }}>
        {phase === 'start' && <StartScreen />}
        {phase === 'card-draw' && <CardDrawPhase />}
        {phase === 'race' && <RacePhase />}
        {phase === 'result' && <ResultPhase />}
        {!phase && (
          <div className="min-h-screen flex items-center justify-center" style={{ color: '#EEF2FF' }}>
            <p>加载中... phase: {String(phase)}</p>
          </div>
        )}
      </div>
      {showGrafana && (
        <div className="w-1/3 min-h-screen sticky top-0">
          <GrafanaPanel />
        </div>
      )}
    </div>
  );
}

export default App;
