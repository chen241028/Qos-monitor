import { Card } from '../types/game';

export const CARD_POOL: Card[] = [
  // Bandwidth cards
  {
    id: 'bw-ssr-1',
    category: 'bandwidth',
    rarity: 'SSR',
    name: '光纤高速通道',
    description: '稳定如一的超高速连接',
    flavorText: '就像城市的主干道，车流顺畅，从不停歇',
    stats: { stability: 95, burst: 85, delay: 5, predictability: 90 },
  },
  {
    id: 'bw-sr-1',
    category: 'bandwidth',
    rarity: 'SR',
    name: '稳定宽带',
    description: '可靠的日常速度',
    flavorText: '如同乡间小路，虽不快，但总能到达',
    stats: { stability: 75, burst: 60, delay: 15, predictability: 80 },
  },
  {
    id: 'bw-r-1',
    category: 'bandwidth',
    rarity: 'R',
    name: '共享网络',
    description: '时快时慢的连接',
    flavorText: '就像早晚高峰的地铁，人少时飞快，人多时寸步难行',
    stats: { stability: 50, burst: 40, delay: 30, predictability: 50 },
  },

  // Latency cards
  {
    id: 'lat-ssr-1',
    category: 'latency',
    rarity: 'SSR',
    name: '零延迟感知',
    description: '几乎瞬间的响应速度',
    flavorText: '就像面对面交谈，话音刚落对方就听到了',
    stats: { stability: 90, burst: 80, delay: 2, predictability: 95 },
  },
  {
    id: 'lat-sr-1',
    category: 'latency',
    rarity: 'SR',
    name: '低延迟连接',
    description: '响应迅速的连接',
    flavorText: '如同打电话，略有延迟但可以接受',
    stats: { stability: 70, burst: 65, delay: 25, predictability: 75 },
  },
  {
    id: 'lat-r-1',
    category: 'latency',
    rarity: 'R',
    name: '延迟波动',
    description: '响应时间不稳定',
    flavorText: '就像隔着海洋喊话，有时听得见，有时要等很久',
    stats: { stability: 45, burst: 35, delay: 80, predictability: 45 },
  },

  // Jitter cards
  {
    id: 'jit-ssr-1',
    category: 'jitter',
    rarity: 'SSR',
    name: '完美时序',
    description: '节奏始终如一',
    flavorText: '就像节拍器，每一拍都精准到位',
    stats: { stability: 98, burst: 75, delay: 3, predictability: 98 },
  },
  {
    id: 'jit-sr-1',
    category: 'jitter',
    rarity: 'SR',
    name: '轻微波动',
    description: '偶尔有节奏变化',
    flavorText: '如同走路的节奏，大部分时间一致，偶尔会调整',
    stats: { stability: 70, burst: 60, delay: 20, predictability: 70 },
  },
  {
    id: 'jit-r-1',
    category: 'jitter',
    rarity: 'R',
    name: '节奏混乱',
    description: '速度变化剧烈',
    flavorText: '就像不熟练的鼓手，节奏忽快忽慢',
    stats: { stability: 40, burst: 50, delay: 50, predictability: 40 },
  },

  // Packet Loss cards
  {
    id: 'pl-ssr-1',
    category: 'packet-loss',
    rarity: 'SSR',
    name: '完美传输',
    description: '数据零丢失',
    flavorText: '就像完美的快递服务，每一件都能准确送达',
    stats: { stability: 99, burst: 90, delay: 2, predictability: 99 },
  },
  {
    id: 'pl-sr-1',
    category: 'packet-loss',
    rarity: 'SR',
    name: '偶有丢包',
    description: '大部分数据正常传输',
    flavorText: '如同邮政服务，偶尔会丢失，但大部分都能送达',
    stats: { stability: 65, burst: 55, delay: 25, predictability: 65 },
  },
  {
    id: 'pl-r-1',
    category: 'packet-loss',
    rarity: 'R',
    name: '数据丢失',
    description: '经常需要重传',
    flavorText: '就像破损的管道，水会从缝隙中漏掉',
    stats: { stability: 35, burst: 30, delay: 60, predictability: 35 },
  },

  // Special Event cards
  {
    id: 'spec-ssr-1',
    category: 'special',
    rarity: 'SSR',
    name: '网络优化',
    description: '临时性能提升',
    flavorText: '就像打开了绿色通道，一切变得顺畅',
    stats: { stability: 85, burst: 95, delay: 5, predictability: 85 },
  },
  {
    id: 'spec-sr-1',
    category: 'special',
    rarity: 'SR',
    name: '流量高峰',
    description: '网络拥堵事件',
    flavorText: '就像节假日的高速公路，车流拥挤，速度变慢',
    stats: { stability: 40, burst: 45, delay: 100, predictability: 50 },
  },
  {
    id: 'spec-r-1',
    category: 'special',
    rarity: 'R',
    name: '随机波动',
    description: '不可预测的变化',
    flavorText: '就像天气，有时晴有时雨，难以预料',
    stats: { stability: 50, burst: 60, delay: 40, predictability: 30 },
  },
];

export function drawCards(count: number = 3): Card[] {
  const shuffled = [...CARD_POOL].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
