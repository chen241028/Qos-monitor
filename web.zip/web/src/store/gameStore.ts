import { create } from 'zustand';
import { GameState, GamePhase, RaceState, Card, RaceParticipant } from '../types/game';
import { drawCards } from '../data/cards';

interface GameStore extends GameState {
  startGame: () => void;
  drawUserCards: () => void;
  startRace: () => void;
  updateRace: (state: Partial<RaceState>) => void;
  endRace: (result: GameState['result']) => void;
  reset: () => void;
}

const initialState: GameState = {
  phase: 'start',
  userCards: [],
  raceState: null,
  result: null,
};

export const useGameStore = create<GameStore>((set, get) => ({
  ...initialState,

  startGame: () => {
    const cards = drawCards(3);
    set({ phase: 'card-draw', userCards: cards, raceState: null, result: null });
  },

  drawUserCards: () => {
    const cards = drawCards(3);
    set({ userCards: cards });
  },

  startRace: () => {
    const { userCards } = get();
    
    // Create opponent with random cards
    const opponentCards = drawCards(3);
    
    const raceState: RaceState = {
      elapsedTime: 0,
      duration: 10000, // 10 seconds
      participants: [
        {
          id: 'user',
          name: '你的网络',
          position: 0,
          speed: 0.5,
          cards: userCards,
        },
        {
          id: 'opponent',
          name: '对手网络',
          position: 0,
          speed: 0.5,
          cards: opponentCards,
        },
      ],
      commentary: [],
    };

    set({ phase: 'race', raceState });
  },

  updateRace: (updates) => {
    const { raceState } = get();
    if (!raceState) return;
    set({ raceState: { ...raceState, ...updates } });
  },

  endRace: (result) => {
    set({ phase: 'result', result });
  },

  reset: () => {
    set(initialState);
  },
}));
