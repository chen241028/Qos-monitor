interface GrafanaPanelProps {
  url?: string;
}

export function GrafanaPanel({ url }: GrafanaPanelProps) {
  const defaultUrl = url || process.env.VITE_GRAFANA_URL || '';

  if (!defaultUrl) {
    return (
      <div className="w-full h-full bg-gray-900/50 border-l border-gray-700 flex items-center justify-center">
        <div className="text-center text-gray-500 p-8">
          <p className="mb-2">Grafana 仪表板</p>
          <p className="text-sm">配置 VITE_GRAFANA_URL 环境变量以显示仪表板</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-gray-900 border-l border-gray-700">
      <iframe
        src={defaultUrl}
        className="w-full h-full border-0"
        title="Grafana Dashboard"
        sandbox="allow-same-origin allow-scripts allow-forms"
      />
    </div>
  );
}
