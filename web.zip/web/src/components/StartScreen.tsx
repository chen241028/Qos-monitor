import { motion } from 'framer-motion';
import { useGameStore } from '../store/gameStore';
import { Play } from 'lucide-react';

export function StartScreen() {
  const startGame = useGameStore((state) => state.startGame);

  console.log('StartScreen rendered');

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#0A0A0F', minHeight: '100vh' }}>
      <div className="text-center max-w-2xl px-6">
        <h1 
          className="text-6xl font-bold mb-4"
          style={{ 
            color: '#EEF2FF', 
            textShadow: '0 0 10px rgba(79, 70, 229, 0.6)'
          }}
        >
          QoS 网络竞速
        </h1>
        
        <p 
          className="text-xl mb-8 leading-relaxed"
          style={{ color: '#9CA3AF' }}
        >
          体验网络质量，而非阅读数字
          <br />
          通过卡片系统了解网络表现，在竞速中感受连接的差异
        </p>

        <button
          onClick={() => {
            console.log('Button clicked, starting game...');
            startGame();
          }}
          style={{
            backgroundColor: '#F97316',
            color: 'white',
            padding: '16px 32px',
            borderRadius: '8px',
            fontSize: '18px',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            margin: '0 auto',
            cursor: 'pointer',
            border: 'none',
            boxShadow: '0 4px 14px 0 rgba(249, 115, 22, 0.3)'
          }}
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#EA580C'}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#F97316'}
        >
          <Play className="w-6 h-6" />
          开始游戏
        </button>

        <p 
          className="text-sm mt-8"
          style={{ color: '#6B7280' }}
        >
          每次运行约 10 秒 · 体验网络性能的差异
        </p>
      </div>
    </div>
  );
}
